\$default\_resource\_type {#variable.default.resource.type}
=========================

This tells smarty what resource type to use implicitly. The default
value is `file`, meaning that `$smarty->display('index.tpl')` and
`$smarty->display('file:index.tpl')` are identical in meaning. See the
[resource](#resources) chapter for more details.
