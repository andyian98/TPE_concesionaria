<?php
require 'smarty/libs/Smarty.class.php';
require 'controllers/AutoController.php';

$smarty = new Smarty;
$smarty->setTemplateDir('templates');
$smarty->setCompileDir('templates_c');

$controller = new AutoController($smarty);
$controller->index();
?>
